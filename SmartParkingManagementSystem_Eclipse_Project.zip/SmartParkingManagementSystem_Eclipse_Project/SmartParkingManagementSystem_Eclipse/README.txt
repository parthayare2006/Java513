SMART PARKING MANAGEMENT SYSTEM - ECLIPSE PROJECT

Project: SmartParkingManagementSystem
Main class: parking.Main
Java compatibility: Java 8

How to open:
1. Extract this ZIP.
2. Open Eclipse.
3. File > Import > Existing Projects into Workspace.
4. Select the extracted SmartParkingManagementSystem folder.
5. Finish.
6. Right-click src/parking/Main.java.
7. Run As > Java Application.

If Eclipse asks for a JRE, select a Java 8 JRE.

package parking;

import javax.swing.BorderFactory;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class Main extends JFrame {
    private static final long serialVersionUID = 1L;
    private static final String DATA_FILE = "parking_data.dat";
    private static final int TOTAL_SLOTS = 20;

    private transient final List<ParkingRecord> records = new ArrayList<>();
    private final JPanel slotPanel = new JPanel(new GridLayout(4, 5, 12, 12));
    private final DefaultTableModel historyModel = new DefaultTableModel(
            new Object[]{"Vehicle", "Type", "Slot", "Owner", "Entry", "Exit", "Fee", "Status"}, 0) {
        private static final long serialVersionUID = 1L;

        @Override
        public boolean isCellEditable(int row, int column) {
            return false;
        }
    };
    private final JTable historyTable = new JTable(historyModel);
    private final JLabel totalLabel = statLabel();
    private final JLabel availableLabel = statLabel();
    private final JLabel occupiedLabel = statLabel();
    private final JLabel revenueLabel = statLabel();

    private JTextField entryVehicle;
    private JTextField entryOwner;
    private JComboBox<String> entryType;
    private JSpinner entrySlot;

    private JTextField exitVehicle;

    private static final Color PRIMARY = new Color(30, 80, 150);
    private static final Color GREEN = new Color(35, 145, 75);
    private static final Color RED = new Color(200, 55, 55);
    private static final Color BG = new Color(242, 245, 249);
    private static final Color DARK = new Color(35, 40, 50);

    @SuppressWarnings("this-escape")
    public Main() {
        setTitle("Smart Parking Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1100, 720);
        setMinimumSize(new Dimension(950, 620));
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        loadData();
        buildUI();
        refreshAll();
    }

    private static JLabel statLabel() {
        JLabel label = new JLabel("0", SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 26));
        return label;
    }

    private void buildUI() {
        add(createHeader(), BorderLayout.NORTH);

        JTabbedPane tabs = new JTabbedPane();
        tabs.addTab("Dashboard", createDashboard());
        tabs.addTab("Vehicle Entry", createEntryPanel());
        tabs.addTab("Vehicle Exit", createExitPanel());
        tabs.addTab("Parking History", createHistoryPanel());
        tabs.addTab("Help", createHelpPanel());
        add(tabs, BorderLayout.CENTER);
    }

    private JPanel createHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(PRIMARY);
        header.setBorder(BorderFactory.createEmptyBorder(15, 25, 15, 25));

        JLabel title = new JLabel("SMART PARKING MANAGEMENT SYSTEM");
        title.setForeground(Color.WHITE);
        title.setFont(new Font("Arial", Font.BOLD, 24));
        header.add(title, BorderLayout.WEST);

        JLabel subtitle = new JLabel("Automatic Slot Allocation • Entry • Exit • Billing");
        subtitle.setForeground(Color.WHITE);
        subtitle.setFont(new Font("Arial", Font.PLAIN, 13));
        header.add(subtitle, BorderLayout.EAST);
        return header;
    }

    private JPanel createDashboard() {
        JPanel root = new JPanel(new BorderLayout(20, 20));
        root.setBackground(BG);
        root.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));

        JPanel stats = new JPanel(new GridLayout(1, 4, 15, 15));
        stats.setOpaque(false);
        stats.add(statCard("TOTAL SLOTS", totalLabel, PRIMARY));
        stats.add(statCard("AVAILABLE", availableLabel, GREEN));
        stats.add(statCard("OCCUPIED", occupiedLabel, RED));
        stats.add(statCard("TOTAL REVENUE", revenueLabel, new Color(150, 100, 30)));

        JPanel parkingBox = new JPanel(new BorderLayout(10, 10));
        parkingBox.setBackground(Color.WHITE);
        parkingBox.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 225, 230)),
                BorderFactory.createEmptyBorder(18, 18, 18, 18)));

        JLabel heading = new JLabel("Parking Slot Layout");
        heading.setFont(new Font("Arial", Font.BOLD, 20));
        heading.setForeground(DARK);
        parkingBox.add(heading, BorderLayout.NORTH);
        parkingBox.add(new JScrollPane(slotPanel), BorderLayout.CENTER);

        root.add(stats, BorderLayout.NORTH);
        root.add(parkingBox, BorderLayout.CENTER);
        return root;
    }

    private JPanel statCard(String title, JLabel value, Color color) {
        JPanel card = new JPanel(new BorderLayout(5, 5));
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 225, 230)),
                BorderFactory.createEmptyBorder(12, 12, 12, 12)));

        JLabel titleLabel = new JLabel(title, SwingConstants.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 12));
        titleLabel.setForeground(color);
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(value, BorderLayout.CENTER);
        return card;
    }

    private JPanel createEntryPanel() {
        JPanel root = formRoot();
        JPanel form = formBox();

        entryVehicle = new JTextField();
        entryOwner = new JTextField();
        entryType = new JComboBox<>(new String[]{"Bike", "Car", "SUV"});
        entrySlot = new JSpinner(new SpinnerNumberModel(0, 0, TOTAL_SLOTS, 1));

        form.add(field("Vehicle Number", entryVehicle));
        form.add(field("Owner Name", entryOwner));
        form.add(field("Vehicle Type", entryType));
        form.add(field("Parking Slot (0 = Auto)", entrySlot));

        JButton park = button("PARK VEHICLE", GREEN);
        park.addActionListener(this::parkVehicle);
        form.add(park);

        root.add(form);
        return root;
    }

    private JPanel createExitPanel() {
        JPanel root = formRoot();
        JPanel form = formBox();

        exitVehicle = new JTextField();
        form.add(field("Vehicle Number", exitVehicle));

        JButton exit = button("PROCESS VEHICLE EXIT", PRIMARY);
        exit.addActionListener(this::exitVehicle);
        form.add(exit);

        root.add(form);
        return root;
    }

    private JPanel createHistoryPanel() {
        JPanel root = new JPanel(new BorderLayout(10, 10));
        root.setBackground(BG);
        root.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        historyTable.setRowHeight(28);
        historyTable.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        root.add(new JScrollPane(historyTable), BorderLayout.CENTER);

        JButton clear = button("CLEAR COMPLETED HISTORY", RED);
        clear.addActionListener(this::clearHistory);
        JPanel bottom = new JPanel();
        bottom.setOpaque(false);
        bottom.add(clear);
        root.add(bottom, BorderLayout.SOUTH);
        return root;
    }

    private JPanel createHelpPanel() {
        JPanel root = new JPanel(new BorderLayout());
        root.setBackground(BG);
        root.setBorder(BorderFactory.createEmptyBorder(25, 35, 25, 35));

        JLabel help = new JLabel("<html><h2>How to use</h2>"
                + "<b>1. Vehicle Entry:</b> Enter vehicle details and choose automatic or manual slot allocation.<br><br>"
                + "<b>2. Dashboard:</b> Green slots are available and red slots are occupied.<br><br>"
                + "<b>3. Vehicle Exit:</b> Enter the vehicle number. The system calculates the parking fee automatically.<br><br>"
                + "<b>4. Parking History:</b> View completed and active parking records.<br><br>"
                + "<b>Rates:</b> Bike ₹20/hour, Car ₹40/hour, SUV ₹60/hour. Minimum one hour is charged.<br><br>"
                + "<b>Data:</b> Parking records are saved locally in parking_data.dat.</html>");
        help.setFont(new Font("Arial", Font.PLAIN, 15));
        root.add(help, BorderLayout.NORTH);
        return root;
    }

    private JPanel formRoot() {
        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(BG);
        root.setBorder(BorderFactory.createEmptyBorder(25, 25, 25, 25));
        return root;
    }

    private JPanel formBox() {
        JPanel box = new JPanel();
        box.setPreferredSize(new Dimension(500, 400));
        box.setBackground(Color.WHITE);
        box.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(220, 225, 230)),
                BorderFactory.createEmptyBorder(30, 35, 30, 35)));
        box.setLayout(new BoxLayout(box, BoxLayout.Y_AXIS));
        return box;
    }

    private JPanel field(String name, java.awt.Component component) {
        JPanel panel = new JPanel(new BorderLayout(8, 8));
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createEmptyBorder(8, 0, 8, 0));

        JLabel label = new JLabel(name);
        label.setPreferredSize(new Dimension(180, 35));
        label.setFont(new Font("Arial", Font.BOLD, 13));
        panel.add(label, BorderLayout.WEST);

        component.setPreferredSize(new Dimension(240, 35));
        panel.add(component, BorderLayout.CENTER);
        return panel;
    }

    private JButton button(String text, Color color) {
        JButton button = new JButton(text);
        button.setBackground(color);
        button.setForeground(Color.WHITE);
        button.setFont(new Font("Arial", Font.BOLD, 13));
        button.setFocusPainted(false);
        button.setMargin(new Insets(10, 18, 10, 18));
        return button;
    }

    private void parkVehicle(ActionEvent event) {
        String vehicle = entryVehicle.getText().trim().toUpperCase();
        String owner = entryOwner.getText().trim();
        String type = String.valueOf(entryType.getSelectedItem());
        int requestedSlot = (Integer) entrySlot.getValue();

        if (vehicle.isEmpty() || owner.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter vehicle number and owner name.");
            return;
        }

        if (findActive(vehicle) != null) {
            JOptionPane.showMessageDialog(this, "This vehicle is already parked.");
            return;
        }

        int slot = requestedSlot == 0 ? findAvailableSlot() : requestedSlot;
        if (slot == -1) {
            JOptionPane.showMessageDialog(this, "No parking slot is available.");
            return;
        }
        if (isSlotOccupied(slot)) {
            JOptionPane.showMessageDialog(this, "Selected slot is already occupied.");
            return;
        }

        ParkingRecord record = new ParkingRecord(vehicle, owner, type, slot, new Date());
        records.add(record);
        saveData();
        refreshAll();

        entryVehicle.setText("");
        entryOwner.setText("");
        entrySlot.setValue(0);
        JOptionPane.showMessageDialog(this,
                "Vehicle parked successfully.\nAllocated Slot: P" + slot);
    }

    private void exitVehicle(ActionEvent event) {
        String vehicle = exitVehicle.getText().trim().toUpperCase();
        if (vehicle.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter a vehicle number.");
            return;
        }

        ParkingRecord record = findActive(vehicle);
        if (record == null) {
            JOptionPane.showMessageDialog(this, "No active parking record found.");
            return;
        }

        Date exitTime = new Date();
        long hours = Math.max(1L, (exitTime.getTime() - record.entryTime.getTime() + 3599999L) / 3600000L);
        int rate = getRate(record.vehicleType);
        int fee = (int) hours * rate;
        record.exitTime = exitTime;
        record.fee = fee;
        record.status = "COMPLETED";

        saveData();
        refreshAll();
        exitVehicle.setText("");

        JOptionPane.showMessageDialog(this,
                "EXIT COMPLETED\n\nVehicle: " + record.vehicleNumber
                        + "\nSlot: P" + record.slot
                        + "\nDuration: " + hours + " hour(s)"
                        + "\nParking Fee: ₹" + fee,
                "Parking Receipt", JOptionPane.INFORMATION_MESSAGE);
    }

    private void clearHistory(ActionEvent event) {
        int result = JOptionPane.showConfirmDialog(this,
                "Delete all completed parking records?",
                "Confirm", JOptionPane.YES_NO_OPTION);
        if (result != JOptionPane.YES_OPTION) {
            return;
        }
        records.removeIf(record -> "COMPLETED".equals(record.status));
        saveData();
        refreshAll();
    }

    private void refreshAll() {
        refreshDashboard();
        refreshSlots();
        refreshHistory();
    }

    private void refreshDashboard() {
        int occupied = countOccupied();
        int revenue = records.stream()
                .filter(record -> "COMPLETED".equals(record.status))
                .mapToInt(record -> record.fee)
                .sum();

        totalLabel.setText(String.valueOf(TOTAL_SLOTS));
        availableLabel.setText(String.valueOf(TOTAL_SLOTS - occupied));
        occupiedLabel.setText(String.valueOf(occupied));
        revenueLabel.setText("₹" + revenue);
    }

    private void refreshSlots() {
        slotPanel.removeAll();
        for (int slot = 1; slot <= TOTAL_SLOTS; slot++) {
            boolean occupied = isSlotOccupied(slot);
            JButton button = new JButton("P" + slot + (occupied ? "\nOCCUPIED" : "\nAVAILABLE"));
            button.setOpaque(true);
            button.setForeground(Color.WHITE);
            button.setBackground(occupied ? RED : GREEN);
            button.setFont(new Font("Arial", Font.BOLD, 12));
            final int selectedSlot = slot;
            button.addActionListener(event -> showSlot(selectedSlot));
            slotPanel.add(button);
        }
        slotPanel.revalidate();
        slotPanel.repaint();
    }

    private void refreshHistory() {
        historyModel.setRowCount(0);
        SimpleDateFormat format = new SimpleDateFormat("dd-MM-yyyy HH:mm");
        for (ParkingRecord record : records) {
            historyModel.addRow(new Object[]{
                    record.vehicleNumber,
                    record.vehicleType,
                    "P" + record.slot,
                    record.owner,
                    format.format(record.entryTime),
                    record.exitTime == null ? "-" : format.format(record.exitTime),
                    record.exitTime == null ? "-" : "₹" + record.fee,
                    record.status
            });
        }
    }

    private void showSlot(int slot) {
        ParkingRecord record = getRecordForSlot(slot);
        if (record == null) {
            JOptionPane.showMessageDialog(this, "P" + slot + " is AVAILABLE.");
            return;
        }
        JOptionPane.showMessageDialog(this,
                "P" + slot + " is OCCUPIED.\n\nVehicle: " + record.vehicleNumber
                        + "\nOwner: " + record.owner
                        + "\nType: " + record.vehicleType
                        + "\nEntry: " + new SimpleDateFormat("dd-MM-yyyy HH:mm").format(record.entryTime));
    }

    private ParkingRecord findActive(String vehicle) {
        for (ParkingRecord record : records) {
            if ("ACTIVE".equals(record.status) && record.vehicleNumber.equalsIgnoreCase(vehicle)) {
                return record;
            }
        }
        return null;
    }

    private ParkingRecord getRecordForSlot(int slot) {
        for (ParkingRecord record : records) {
            if (record.slot == slot && "ACTIVE".equals(record.status)) {
                return record;
            }
        }
        return null;
    }

    private boolean isSlotOccupied(int slot) {
        return getRecordForSlot(slot) != null;
    }

    private int countOccupied() {
        int count = 0;
        for (ParkingRecord record : records) {
            if ("ACTIVE".equals(record.status)) {
                count++;
            }
        }
        return count;
    }

    private int findAvailableSlot() {
        for (int slot = 1; slot <= TOTAL_SLOTS; slot++) {
            if (!isSlotOccupied(slot)) {
                return slot;
            }
        }
        return -1;
    }

    private int getRate(String type) {
        switch (type) {
            case "Bike":
                return 20;
            case "SUV":
                return 60;
            default:
                return 40;
        }
    }

    private void saveData() {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            output.writeObject(records);
        } catch (Exception exception) {
            JOptionPane.showMessageDialog(this, "Could not save parking data.");
        }
    }

    @SuppressWarnings("unchecked")
    private void loadData() {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            records.clear();
            records.addAll((List<ParkingRecord>) input.readObject());
        } catch (Exception ignored) {
            // First run: no data file exists yet.
        }
    }

    private static class ParkingRecord implements Serializable {
        private static final long serialVersionUID = 1L;

        private final String vehicleNumber;
        private final String owner;
        private final String vehicleType;
        private final int slot;
        private final Date entryTime;
        private Date exitTime;
        private int fee;
        private String status = "ACTIVE";

        ParkingRecord(String vehicleNumber, String owner, String vehicleType, int slot, Date entryTime) {
            this.vehicleNumber = vehicleNumber;
            this.owner = owner;
            this.vehicleType = vehicleType;
            this.slot = slot;
            this.entryTime = entryTime;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Main().setVisible(true));
    }
}
